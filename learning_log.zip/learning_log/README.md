Learning logs from 'Python Crash Course - Eirc Matthes'

Ensure you have python 3.8.11 or equivalent installed
1) Create a conda environment called 'll_env' from the command line:
conda create --name ll_env python=3.8.11
2) Activate
conda active ll_env
3) Install package from requirements.txt:
conda install --file requirements.txt

Start the server
4) From the learning_log directory start the server:
python manage.py runserver
5) Check out the application by going to: http://127.0.0.1:8000/

