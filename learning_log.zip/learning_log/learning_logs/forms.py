from django import forms

from .models import Topic, Entry

# Create your models here.

class TopicForm(forms.ModelForm):
	"""A topic the user is learning about"""
	class Meta:
		model = Topic
		fields = ['text']
		labels = {'text' : ''}

class EntryForm(forms.ModelForm):
	"""A topic the user is learning about"""
	class Meta:
		model = Entry
		fields = ['text']
		labels = {'text' : ''}
		widgets = {'text': forms.Textarea(attrs={'cols':80})} 